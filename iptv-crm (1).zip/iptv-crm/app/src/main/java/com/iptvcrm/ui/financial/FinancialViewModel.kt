package com.iptvcrm.ui.financial

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.iptvcrm.data.database.AppDatabase
import com.iptvcrm.data.entities.Expense
import kotlinx.coroutines.launch

class FinancialViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val expenseDao = db.expenseDao()
    private val clientDao = db.clientDao()

    val allExpenses: LiveData<List<Expense>> = expenseDao.getAllExpenses()
    val totalMonthlyExpenses: LiveData<Double?> = expenseDao.getTotalMonthlyExpenses()
    val expensesByCategory = expenseDao.getExpensesByCategory()
    val totalRevenue: LiveData<Double?> = clientDao.getTotalMonthlyRevenue()
    val activeClientCount: LiveData<Int> = clientDao.getActiveClientCount()

    fun addExpense(expense: Expense) = viewModelScope.launch {
        expenseDao.insertExpense(expense)
    }

    fun deleteExpense(expense: Expense) = viewModelScope.launch {
        expenseDao.deleteExpense(expense)
    }

    fun updateExpense(expense: Expense) = viewModelScope.launch {
        expenseDao.updateExpense(expense)
    }
}
