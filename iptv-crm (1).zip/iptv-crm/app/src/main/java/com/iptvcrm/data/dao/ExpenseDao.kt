package com.iptvcrm.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.iptvcrm.data.entities.Expense

@Dao
interface ExpenseDao {

    @Query("SELECT * FROM expenses ORDER BY date DESC")
    fun getAllExpenses(): LiveData<List<Expense>>

    @Query("SELECT * FROM expenses WHERE isRecurring = 1")
    fun getRecurringExpenses(): LiveData<List<Expense>>

    @Query("SELECT SUM(amount) FROM expenses WHERE isRecurring = 1")
    fun getTotalMonthlyExpenses(): LiveData<Double?>

    @Query("SELECT SUM(amount) FROM expenses WHERE isRecurring = 0 AND date >= :startOfMonth AND date <= :endOfMonth")
    suspend fun getOneTimeExpensesForMonth(startOfMonth: Long, endOfMonth: Long): Double?

    @Query("SELECT category, SUM(amount) as total FROM expenses GROUP BY category")
    fun getExpensesByCategory(): LiveData<List<CategoryTotal>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: Expense): Long

    @Update
    suspend fun updateExpense(expense: Expense)

    @Delete
    suspend fun deleteExpense(expense: Expense)
}

data class CategoryTotal(
    val category: String,
    val total: Double
)
