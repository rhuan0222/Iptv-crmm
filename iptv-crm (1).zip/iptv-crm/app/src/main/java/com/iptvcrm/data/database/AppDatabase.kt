package com.iptvcrm.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.iptvcrm.data.dao.*
import com.iptvcrm.data.entities.*

@Database(
    entities = [Client::class, Server::class, Expense::class, Payment::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun clientDao(): ClientDao
    abstract fun serverDao(): ServerDao
    abstract fun expenseDao(): ExpenseDao
    abstract fun paymentDao(): PaymentDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "iptv_crm_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
