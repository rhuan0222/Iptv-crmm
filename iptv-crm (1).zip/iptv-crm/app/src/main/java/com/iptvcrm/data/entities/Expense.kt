package com.iptvcrm.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val category: String,         // "Distribuição", "Panfleto", "Mídia Paga", "Outro"
    val description: String,
    val amount: Double,
    val isRecurring: Boolean = false,  // gasto mensal recorrente
    val date: Long = System.currentTimeMillis()
)
