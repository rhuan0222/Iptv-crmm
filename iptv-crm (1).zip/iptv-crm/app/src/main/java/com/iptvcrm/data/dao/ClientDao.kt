package com.iptvcrm.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.iptvcrm.data.entities.Client

@Dao
interface ClientDao {

    @Query("SELECT * FROM clients ORDER BY name ASC")
    fun getAllClients(): LiveData<List<Client>>

    @Query("SELECT * FROM clients WHERE active = 1 ORDER BY name ASC")
    fun getActiveClients(): LiveData<List<Client>>

    @Query("SELECT * FROM clients WHERE id = :id")
    suspend fun getClientById(id: Long): Client?

    @Query("SELECT COUNT(*) FROM clients WHERE active = 1")
    fun getActiveClientCount(): LiveData<Int>

    @Query("SELECT SUM(planValue) FROM clients WHERE active = 1")
    fun getTotalMonthlyRevenue(): LiveData<Double?>

    @Query("SELECT * FROM clients WHERE serverId = :serverId")
    fun getClientsByServer(serverId: Long): LiveData<List<Client>>

    @Query("SELECT * FROM clients WHERE origin = :origin")
    fun getClientsByOrigin(origin: String): LiveData<List<Client>>

    @Query("SELECT origin, COUNT(*) as count FROM clients WHERE active = 1 GROUP BY origin")
    fun getClientsByOriginCount(): LiveData<List<OriginCount>>

    @Query("SELECT SUM(creditsUsed) FROM clients WHERE active = 1 AND serverId = :serverId")
    suspend fun getCreditsUsedByServer(serverId: Long): Int?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClient(client: Client): Long

    @Update
    suspend fun updateClient(client: Client)

    @Delete
    suspend fun deleteClient(client: Client)

    @Query("UPDATE clients SET active = 0 WHERE id = :id")
    suspend fun deactivateClient(id: Long)
}

data class OriginCount(
    val origin: String,
    val count: Int
)
