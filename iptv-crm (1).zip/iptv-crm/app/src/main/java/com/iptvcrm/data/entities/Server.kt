package com.iptvcrm.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "servers")
data class Server(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val costPerCredit: Double,    // custo por crédito
    val totalCredits: Int,        // total de créditos disponíveis
    val notes: String = ""
)
