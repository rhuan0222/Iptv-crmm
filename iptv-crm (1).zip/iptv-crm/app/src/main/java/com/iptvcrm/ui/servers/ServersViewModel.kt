package com.iptvcrm.ui.servers

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.iptvcrm.data.database.AppDatabase
import com.iptvcrm.data.entities.Server
import kotlinx.coroutines.launch

class ServersViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val serverDao = db.serverDao()
    private val clientDao = db.clientDao()

    val allServers: LiveData<List<Server>> = serverDao.getAllServers()

    fun addServer(server: Server) = viewModelScope.launch {
        serverDao.insertServer(server)
    }

    fun updateServer(server: Server) = viewModelScope.launch {
        serverDao.updateServer(server)
    }

    fun deleteServer(server: Server) = viewModelScope.launch {
        serverDao.deleteServer(server)
    }

    fun getClientsByServer(serverId: Long) = clientDao.getClientsByServer(serverId)

    suspend fun getCreditsUsed(serverId: Long): Int = clientDao.getCreditsUsedByServer(serverId) ?: 0
}
