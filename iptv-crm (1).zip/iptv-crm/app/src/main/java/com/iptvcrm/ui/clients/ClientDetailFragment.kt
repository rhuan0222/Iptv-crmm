package com.iptvcrm.ui.clients

import android.os.Bundle
import android.view.*
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.google.android.material.snackbar.Snackbar
import com.iptvcrm.data.entities.Client
import com.iptvcrm.data.entities.Server
import com.iptvcrm.databinding.FragmentClientDetailBinding

class ClientDetailFragment : Fragment() {

    private var _binding: FragmentClientDetailBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ClientsViewModel by viewModels()
    private val args: ClientDetailFragmentArgs by navArgs()
    private var existingClient: Client? = null
    private var servers: List<Server> = emptyList()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentClientDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val origins = listOf("Panfleto", "Internet", "Boca a Boca", "Outro")
        binding.spinnerOrigin.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, origins)

        viewModel.allServers.observe(viewLifecycleOwner) { serverList ->
            servers = serverList
            val serverNames = serverList.map { it.name }
            binding.spinnerServer.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, serverNames)
        }

        if (args.clientId != -1L) {
            loadExistingClient(args.clientId)
        }

        binding.btnSave.setOnClickListener { saveClient() }
    }

    private fun loadExistingClient(id: Long) {
        viewModel.allClients.observe(viewLifecycleOwner) { clients ->
            val client = clients.find { it.id == id } ?: return@observe
            existingClient = client
            binding.etName.setText(client.name)
            binding.etPhone.setText(client.phone)
            binding.etAddress.setText(client.address)
            binding.etPlan.setText(client.plan)
            binding.etPlanValue.setText(client.planValue.toString())
            binding.etDueDay.setText(client.dueDay.toString())
            binding.etCredits.setText(client.creditsUsed.toString())
            binding.etNotes.setText(client.notes)
        }
    }

    private fun saveClient() {
        val name = binding.etName.text.toString().trim()
        val phone = binding.etPhone.text.toString().trim()
        val address = binding.etAddress.text.toString().trim()
        val plan = binding.etPlan.text.toString().trim()
        val planValueStr = binding.etPlanValue.text.toString().trim()
        val dueDayStr = binding.etDueDay.text.toString().trim()
        val creditsStr = binding.etCredits.text.toString().trim()
        val origin = binding.spinnerOrigin.selectedItem?.toString() ?: "Outro"
        val selectedServer = servers.getOrNull(binding.spinnerServer.selectedItemPosition)

        if (name.isEmpty() || plan.isEmpty() || planValueStr.isEmpty() || dueDayStr.isEmpty()) {
            Snackbar.make(binding.root, "Preencha os campos obrigatórios", Snackbar.LENGTH_SHORT).show()
            return
        }

        val client = (existingClient ?: Client(
            name = "", phone = "", address = "", plan = "", planValue = 0.0,
            dueDay = 1, serverId = 0L, origin = ""
        )).copy(
            name = name,
            phone = phone,
            address = address,
            plan = plan,
            planValue = planValueStr.toDoubleOrNull() ?: 0.0,
            dueDay = dueDayStr.toIntOrNull() ?: 1,
            serverId = selectedServer?.id ?: 0L,
            creditsUsed = creditsStr.toIntOrNull() ?: 1,
            origin = origin,
            notes = binding.etNotes.text.toString().trim()
        )

        if (existingClient != null) viewModel.updateClient(client)
        else viewModel.addClient(client)

        findNavController().popBackStack()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
