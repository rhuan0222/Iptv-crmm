package com.iptvcrm.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "payments")
data class Payment(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val clientId: Long,
    val amount: Double,
    val date: Long = System.currentTimeMillis(),
    val referenceMonth: String,   // "2024-01", "2024-02" etc
    val paid: Boolean = true,
    val notes: String = ""
)
