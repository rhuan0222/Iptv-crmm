package com.iptvcrm.ui.clients

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.iptvcrm.data.entities.Client
import com.iptvcrm.databinding.ItemClientBinding
import java.text.NumberFormat
import java.util.Locale

class ClientsAdapter(
    private val onEdit: (Client) -> Unit,
    private val onToggleActive: (Client) -> Unit,
    private val onRegisterPayment: (Client) -> Unit
) : ListAdapter<Client, ClientsAdapter.ViewHolder>(DiffCallback()) {

    private var originalList: List<Client> = emptyList()
    private val currencyFormat = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))

    override fun submitList(list: List<Client>?) {
        originalList = list ?: emptyList()
        super.submitList(list)
    }

    fun filter(query: String) {
        val filtered = if (query.isEmpty()) originalList
        else originalList.filter {
            it.name.contains(query, ignoreCase = true) ||
            it.phone.contains(query, ignoreCase = true)
        }
        super.submitList(filtered)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemClientBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(private val binding: ItemClientBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(client: Client) {
            binding.tvClientName.text = client.name
            binding.tvClientPhone.text = client.phone
            binding.tvClientPlan.text = "Plano: ${client.plan} — ${currencyFormat.format(client.planValue)}/mês"
            binding.tvDueDay.text = "Vence dia ${client.dueDay}"
            binding.tvOrigin.text = "Origem: ${client.origin}"
            binding.tvStatus.text = if (client.active) "✅ Ativo" else "❌ Inativo"

            binding.btnEdit.setOnClickListener { onEdit(client) }
            binding.btnToggleActive.text = if (client.active) "Desativar" else "Ativar"
            binding.btnToggleActive.setOnClickListener { onToggleActive(client) }
            binding.btnPayment.setOnClickListener { onRegisterPayment(client) }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<Client>() {
        override fun areItemsTheSame(oldItem: Client, newItem: Client) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: Client, newItem: Client) = oldItem == newItem
    }
}
