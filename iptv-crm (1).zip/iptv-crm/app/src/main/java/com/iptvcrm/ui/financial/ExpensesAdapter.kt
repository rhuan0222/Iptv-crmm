package com.iptvcrm.ui.financial

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.iptvcrm.data.entities.Expense
import com.iptvcrm.databinding.ItemExpenseBinding
import java.text.NumberFormat
import java.util.Locale

class ExpensesAdapter(
    private val onDelete: (Expense) -> Unit
) : ListAdapter<Expense, ExpensesAdapter.ViewHolder>(DiffCallback()) {

    private val currencyFormat = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemExpenseBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(private val binding: ItemExpenseBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(expense: Expense) {
            binding.tvExpenseDescription.text = expense.description
            binding.tvExpenseCategory.text = expense.category
            binding.tvExpenseAmount.text = currencyFormat.format(expense.amount)
            binding.tvRecurring.text = if (expense.isRecurring) "🔄 Mensal" else "📌 Único"
            binding.btnDeleteExpense.setOnClickListener { onDelete(expense) }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<Expense>() {
        override fun areItemsTheSame(oldItem: Expense, newItem: Expense) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: Expense, newItem: Expense) = oldItem == newItem
    }
}
