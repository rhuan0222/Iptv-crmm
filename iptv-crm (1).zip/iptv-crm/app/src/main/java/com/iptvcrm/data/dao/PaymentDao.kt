package com.iptvcrm.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.iptvcrm.data.entities.Payment

@Dao
interface PaymentDao {

    @Query("SELECT * FROM payments WHERE clientId = :clientId ORDER BY date DESC")
    fun getPaymentsByClient(clientId: Long): LiveData<List<Payment>>

    @Query("SELECT * FROM payments ORDER BY date DESC")
    fun getAllPayments(): LiveData<List<Payment>>

    @Query("SELECT SUM(amount) FROM payments WHERE referenceMonth = :month AND paid = 1")
    suspend fun getTotalRevenueForMonth(month: String): Double?

    @Query("SELECT * FROM payments WHERE paid = 0")
    fun getPendingPayments(): LiveData<List<Payment>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: Payment): Long

    @Update
    suspend fun updatePayment(payment: Payment)

    @Delete
    suspend fun deletePayment(payment: Payment)
}
