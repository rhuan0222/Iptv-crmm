package com.iptvcrm.ui.clients

import android.os.Bundle
import android.view.*
import androidx.appcompat.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.iptvcrm.R
import com.iptvcrm.data.entities.Client
import com.iptvcrm.databinding.FragmentClientsBinding

class ClientsFragment : Fragment() {

    private var _binding: FragmentClientsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ClientsViewModel by viewModels()
    private lateinit var adapter: ClientsAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentClientsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        setupSearch()
        setupFab()

        viewModel.allClients.observe(viewLifecycleOwner) { clients ->
            adapter.submitList(clients)
            binding.tvEmpty.visibility = if (clients.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun setupRecyclerView() {
        adapter = ClientsAdapter(
            onEdit = { client -> navigateToClientDetail(client) },
            onToggleActive = { client ->
                if (client.active) viewModel.deactivateClient(client.id)
                else viewModel.updateClient(client.copy(active = true))
            },
            onRegisterPayment = { client ->
                showPaymentDialog(client)
            }
        )
        binding.recyclerClients.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerClients.adapter = adapter
    }

    private fun setupSearch() {
        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?) = false
            override fun onQueryTextChange(newText: String?): Boolean {
                adapter.filter(newText ?: "")
                return true
            }
        })
    }

    private fun setupFab() {
        binding.fabAddClient.setOnClickListener {
            navigateToClientDetail(null)
        }
    }

    private fun navigateToClientDetail(client: Client?) {
        val action = ClientsFragmentDirections.actionClientsToClientDetail(client?.id ?: -1L)
        findNavController().navigate(action)
    }

    private fun showPaymentDialog(client: Client) {
        val dialog = PaymentDialogFragment.newInstance(client.id, client.planValue)
        dialog.show(childFragmentManager, "payment_dialog")
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
