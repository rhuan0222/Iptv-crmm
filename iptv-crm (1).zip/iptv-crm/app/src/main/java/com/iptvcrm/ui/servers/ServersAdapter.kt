package com.iptvcrm.ui.servers

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.iptvcrm.data.entities.Server
import com.iptvcrm.databinding.ItemServerBinding
import java.text.NumberFormat
import java.util.Locale

class ServersAdapter(
    private val onEdit: (Server) -> Unit,
    private val onDelete: (Server) -> Unit,
    private val onViewClients: (Server) -> Unit,
    private val getCreditsInfo: (Server, (used: Int, available: Int) -> Unit) -> Unit
) : ListAdapter<Server, ServersAdapter.ViewHolder>(DiffCallback()) {

    private val currencyFormat = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemServerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(private val binding: ItemServerBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(server: Server) {
            binding.tvServerName.text = server.name
            binding.tvCostPerCredit.text = "Custo por crédito: ${currencyFormat.format(server.costPerCredit)}"
            binding.tvTotalCredits.text = "Total de créditos: ${server.totalCredits}"
            binding.tvNotes.text = server.notes

            getCreditsInfo(server) { used, available ->
                binding.tvCreditsUsed.text = "Usados: $used | Disponíveis: $available"
            }

            binding.btnEditServer.setOnClickListener { onEdit(server) }
            binding.btnDeleteServer.setOnClickListener { onDelete(server) }
            binding.btnViewClients.setOnClickListener { onViewClients(server) }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<Server>() {
        override fun areItemsTheSame(oldItem: Server, newItem: Server) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: Server, newItem: Server) = oldItem == newItem
    }
}
