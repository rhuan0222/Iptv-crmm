package com.iptvcrm.ui.financial

import android.os.Bundle
import android.view.*
import android.widget.ArrayAdapter
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.snackbar.Snackbar
import com.iptvcrm.data.entities.Expense
import com.iptvcrm.databinding.DialogAddExpenseBinding
import com.iptvcrm.databinding.FragmentFinancialBinding
import java.text.NumberFormat
import java.util.Locale

class FinancialFragment : Fragment() {

    private var _binding: FragmentFinancialBinding? = null
    private val binding get() = _binding!!
    private val viewModel: FinancialViewModel by viewModels()
    private lateinit var adapter: ExpensesAdapter
    private val currencyFormat = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentFinancialBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        observeData()
        binding.fabAddExpense.setOnClickListener { showAddExpenseDialog() }
    }

    private fun setupRecyclerView() {
        adapter = ExpensesAdapter { expense -> viewModel.deleteExpense(expense) }
        binding.recyclerExpenses.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerExpenses.adapter = adapter
    }

    private fun observeData() {
        viewModel.allExpenses.observe(viewLifecycleOwner) { expenses ->
            adapter.submitList(expenses)
        }

        viewModel.totalRevenue.observe(viewLifecycleOwner) { updateSummary() }
        viewModel.totalMonthlyExpenses.observe(viewLifecycleOwner) { updateSummary() }
        viewModel.activeClientCount.observe(viewLifecycleOwner) { updateSummary() }
    }

    private fun updateSummary() {
        val revenue = viewModel.totalRevenue.value ?: 0.0
        val expenses = viewModel.totalMonthlyExpenses.value ?: 0.0
        val clients = viewModel.activeClientCount.value ?: 0
        val profit = revenue - expenses
        val costPerClient = if (clients > 0) expenses / clients else 0.0

        binding.tvTotalRevenue.text = "Faturamento: ${currencyFormat.format(revenue)}"
        binding.tvTotalExpenses.text = "Gastos: ${currencyFormat.format(expenses)}"
        binding.tvProfit.text = "Lucro: ${currencyFormat.format(profit)}"
        binding.tvCostPerClient.text = "Custo por cliente: ${currencyFormat.format(costPerClient)}"
        binding.tvCac.text = "CAC: ${currencyFormat.format(if (clients > 0) expenses / clients else 0.0)}"
    }

    private fun showAddExpenseDialog() {
        val dialogBinding = DialogAddExpenseBinding.inflate(layoutInflater)
        val categories = listOf("Distribuição", "Panfleto", "Mídia Paga", "Servidor", "Outro")
        dialogBinding.spinnerCategory.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, categories)

        AlertDialog.Builder(requireContext())
            .setTitle("Adicionar Gasto")
            .setView(dialogBinding.root)
            .setPositiveButton("Salvar") { _, _ ->
                val desc = dialogBinding.etDescription.text.toString().trim()
                val amountStr = dialogBinding.etAmount.text.toString().trim()
                val category = dialogBinding.spinnerCategory.selectedItem?.toString() ?: "Outro"
                val isRecurring = dialogBinding.checkRecurring.isChecked

                if (desc.isEmpty() || amountStr.isEmpty()) {
                    Snackbar.make(binding.root, "Preencha todos os campos", Snackbar.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                viewModel.addExpense(
                    Expense(
                        category = category,
                        description = desc,
                        amount = amountStr.toDoubleOrNull() ?: 0.0,
                        isRecurring = isRecurring
                    )
                )
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
