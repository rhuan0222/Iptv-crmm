package com.iptvcrm.ui.servers

import android.os.Bundle
import android.view.*
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.iptvcrm.data.entities.Server
import com.iptvcrm.databinding.DialogAddServerBinding
import com.iptvcrm.databinding.FragmentServersBinding
import kotlinx.coroutines.launch

class ServersFragment : Fragment() {

    private var _binding: FragmentServersBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ServersViewModel by viewModels()
    private lateinit var adapter: ServersAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentServersBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()

        viewModel.allServers.observe(viewLifecycleOwner) { servers ->
            adapter.submitList(servers)
            binding.tvEmpty.visibility = if (servers.isEmpty()) View.VISIBLE else View.GONE
        }

        binding.fabAddServer.setOnClickListener { showAddServerDialog() }
    }

    private fun setupRecyclerView() {
        adapter = ServersAdapter(
            onEdit = { server -> showEditServerDialog(server) },
            onDelete = { server -> viewModel.deleteServer(server) },
            onViewClients = { server ->
                viewModel.getClientsByServer(server.id).observe(viewLifecycleOwner) { clients ->
                    val names = clients.joinToString("\n") { "• ${it.name} (${it.creditsUsed} crédito(s))" }
                    AlertDialog.Builder(requireContext())
                        .setTitle("Clientes em ${server.name}")
                        .setMessage(if (names.isEmpty()) "Nenhum cliente neste server" else names)
                        .setPositiveButton("OK", null)
                        .show()
                }
            },
            getCreditsInfo = { server, callback ->
                lifecycleScope.launch {
                    val used = viewModel.getCreditsUsed(server.id)
                    callback(used, server.totalCredits - used)
                }
            }
        )
        binding.recyclerServers.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerServers.adapter = adapter
    }

    private fun showAddServerDialog(existingServer: Server? = null) {
        val dialogBinding = DialogAddServerBinding.inflate(layoutInflater)
        existingServer?.let {
            dialogBinding.etServerName.setText(it.name)
            dialogBinding.etCostPerCredit.setText(it.costPerCredit.toString())
            dialogBinding.etTotalCredits.setText(it.totalCredits.toString())
            dialogBinding.etServerNotes.setText(it.notes)
        }

        AlertDialog.Builder(requireContext())
            .setTitle(if (existingServer != null) "Editar Server" else "Adicionar Server")
            .setView(dialogBinding.root)
            .setPositiveButton("Salvar") { _, _ ->
                val name = dialogBinding.etServerName.text.toString().trim()
                val cost = dialogBinding.etCostPerCredit.text.toString().toDoubleOrNull() ?: 0.0
                val credits = dialogBinding.etTotalCredits.text.toString().toIntOrNull() ?: 0
                val notes = dialogBinding.etServerNotes.text.toString().trim()

                if (name.isEmpty()) return@setPositiveButton

                val server = (existingServer ?: Server(name = "", costPerCredit = 0.0, totalCredits = 0)).copy(
                    name = name, costPerCredit = cost, totalCredits = credits, notes = notes
                )
                if (existingServer != null) viewModel.updateServer(server)
                else viewModel.addServer(server)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showEditServerDialog(server: Server) = showAddServerDialog(server)

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
