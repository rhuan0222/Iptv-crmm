package com.iptvcrm.ui.clients

import android.app.Dialog
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.viewModels
import com.iptvcrm.databinding.DialogPaymentBinding

class PaymentDialogFragment : DialogFragment() {

    private val viewModel: ClientsViewModel by viewModels({ requireParentFragment() })

    companion object {
        fun newInstance(clientId: Long, defaultAmount: Double): PaymentDialogFragment {
            return PaymentDialogFragment().apply {
                arguments = Bundle().apply {
                    putLong("clientId", clientId)
                    putDouble("defaultAmount", defaultAmount)
                }
            }
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val binding = DialogPaymentBinding.inflate(layoutInflater)
        val clientId = arguments?.getLong("clientId") ?: return super.onCreateDialog(savedInstanceState)
        val defaultAmount = arguments?.getDouble("defaultAmount") ?: 0.0

        binding.etPaymentAmount.setText(defaultAmount.toString())

        return AlertDialog.Builder(requireContext())
            .setTitle("Registrar Pagamento")
            .setView(binding.root)
            .setPositiveButton("Salvar") { _, _ ->
                val amount = binding.etPaymentAmount.text.toString().toDoubleOrNull() ?: defaultAmount
                viewModel.addPayment(clientId, amount)
            }
            .setNegativeButton("Cancelar", null)
            .create()
    }
}
