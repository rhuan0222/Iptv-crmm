package com.iptvcrm.ui.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.iptvcrm.databinding.FragmentDashboardBinding
import java.text.NumberFormat
import java.util.Locale

class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!
    private val viewModel: DashboardViewModel by viewModels()
    private val currencyFormat = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        observeData()
    }

    private fun observeData() {
        viewModel.activeClientCount.observe(viewLifecycleOwner) { count ->
            binding.tvClientCount.text = count?.toString() ?: "0"
        }

        viewModel.totalMonthlyRevenue.observe(viewLifecycleOwner) { revenue ->
            binding.tvRevenue.text = currencyFormat.format(revenue ?: 0.0)
        }

        viewModel.totalMonthlyExpenses.observe(viewLifecycleOwner) { expenses ->
            binding.tvExpenses.text = currencyFormat.format(expenses ?: 0.0)
        }

        viewModel.totalMonthlyRevenue.observe(viewLifecycleOwner) { updateProfit() }
        viewModel.totalMonthlyExpenses.observe(viewLifecycleOwner) { updateProfit() }

        viewModel.projectionData.observe(viewLifecycleOwner) { projections ->
            setupProjectionChart(projections)
        }

        viewModel.clientsByOrigin.observe(viewLifecycleOwner) { origins ->
            setupOriginChart(origins)
        }
    }

    private fun updateProfit() {
        val revenue = viewModel.totalMonthlyRevenue.value ?: 0.0
        val expenses = viewModel.totalMonthlyExpenses.value ?: 0.0
        val profit = revenue - expenses
        binding.tvProfit.text = currencyFormat.format(profit)
        binding.tvProfit.setTextColor(
            resources.getColor(
                if (profit >= 0) android.R.color.holo_green_dark else android.R.color.holo_red_dark,
                null
            )
        )
    }

    private fun setupProjectionChart(projections: List<DashboardViewModel.MonthProjection>) {
        if (projections.isEmpty()) return

        val revenueEntries = projections.mapIndexed { i, p -> Entry(i.toFloat(), p.revenue.toFloat()) }
        val expenseEntries = projections.mapIndexed { i, p -> Entry(i.toFloat(), p.expenses.toFloat()) }
        val profitEntries = projections.mapIndexed { i, p -> Entry(i.toFloat(), p.accumulatedProfit.toFloat()) }

        val revenueSet = LineDataSet(revenueEntries, "Faturamento").apply {
            color = android.graphics.Color.parseColor("#4CAF50")
            setCircleColor(android.graphics.Color.parseColor("#4CAF50"))
            lineWidth = 2f
        }
        val expenseSet = LineDataSet(expenseEntries, "Gastos").apply {
            color = android.graphics.Color.parseColor("#F44336")
            setCircleColor(android.graphics.Color.parseColor("#F44336"))
            lineWidth = 2f
        }
        val profitSet = LineDataSet(profitEntries, "Lucro Acumulado").apply {
            color = android.graphics.Color.parseColor("#2196F3")
            setCircleColor(android.graphics.Color.parseColor("#2196F3"))
            lineWidth = 2f
            enableDashedLine(10f, 5f, 0f)
        }

        binding.chartProjection.apply {
            data = LineData(revenueSet, expenseSet, profitSet)
            xAxis.valueFormatter = IndexAxisValueFormatter(projections.map { it.monthLabel })
            xAxis.labelRotationAngle = -45f
            description.isEnabled = false
            legend.isEnabled = true
            setNoDataText("Sem dados ainda")
            animateX(500)
            invalidate()
        }
    }

    private fun setupOriginChart(origins: List<com.iptvcrm.data.dao.OriginCount>) {
        if (origins.isEmpty()) return

        val entries = origins.map { PieEntry(it.count.toFloat(), it.origin) }
        val colors = listOf(
            android.graphics.Color.parseColor("#4CAF50"),
            android.graphics.Color.parseColor("#2196F3"),
            android.graphics.Color.parseColor("#FF9800"),
            android.graphics.Color.parseColor("#9C27B0")
        )

        val dataSet = PieDataSet(entries, "Origem dos Clientes").apply {
            this.colors = colors
            valueTextSize = 12f
        }

        binding.chartOrigin.apply {
            data = PieData(dataSet)
            description.isEnabled = false
            legend.isEnabled = true
            isDrawHoleEnabled = true
            holeRadius = 40f
            setNoDataText("Sem dados ainda")
            animateY(500)
            invalidate()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
