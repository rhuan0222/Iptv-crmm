package com.iptvcrm.ui.clients

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.iptvcrm.data.database.AppDatabase
import com.iptvcrm.data.entities.Client
import com.iptvcrm.data.entities.Payment
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class ClientsViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val clientDao = db.clientDao()
    private val paymentDao = db.paymentDao()
    private val serverDao = db.serverDao()

    val allClients: LiveData<List<Client>> = clientDao.getAllClients()
    val activeClients: LiveData<List<Client>> = clientDao.getActiveClients()
    val allServers = serverDao.getAllServers()

    fun addClient(client: Client) = viewModelScope.launch {
        clientDao.insertClient(client)
    }

    fun updateClient(client: Client) = viewModelScope.launch {
        clientDao.updateClient(client)
    }

    fun deactivateClient(id: Long) = viewModelScope.launch {
        clientDao.deactivateClient(id)
    }

    fun deleteClient(client: Client) = viewModelScope.launch {
        clientDao.deleteClient(client)
    }

    fun addPayment(clientId: Long, amount: Double) = viewModelScope.launch {
        val sdf = SimpleDateFormat("yyyy-MM", Locale.getDefault())
        val month = sdf.format(Date())
        paymentDao.insertPayment(
            Payment(
                clientId = clientId,
                amount = amount,
                referenceMonth = month
            )
        )
    }

    fun getPaymentHistory(clientId: Long) = paymentDao.getPaymentsByClient(clientId)
}
