package com.iptvcrm.ui.dashboard

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.viewModelScope
import com.iptvcrm.data.database.AppDatabase
import com.iptvcrm.data.entities.Client
import kotlinx.coroutines.launch
import java.util.Calendar

class DashboardViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val clientDao = db.clientDao()
    private val expenseDao = db.expenseDao()
    private val serverDao = db.serverDao()

    val activeClientCount: LiveData<Int> = clientDao.getActiveClientCount()
    val totalMonthlyRevenue: LiveData<Double?> = clientDao.getTotalMonthlyRevenue()
    val totalMonthlyExpenses: LiveData<Double?> = expenseDao.getTotalMonthlyExpenses()
    val clientsByOrigin = clientDao.getClientsByOriginCount()
    val allServers = serverDao.getAllServers()
    val activeClients: LiveData<List<Client>> = clientDao.getActiveClients()

    // Projeção para os próximos 24 meses
    data class MonthProjection(
        val monthLabel: String,
        val revenue: Double,
        val expenses: Double,
        val profit: Double,
        val accumulatedProfit: Double
    )

    val projectionData = MediatorLiveData<List<MonthProjection>>()

    init {
        projectionData.addSource(totalMonthlyRevenue) { updateProjection() }
        projectionData.addSource(totalMonthlyExpenses) { updateProjection() }
    }

    private fun updateProjection() {
        val revenue = totalMonthlyRevenue.value ?: 0.0
        val expenses = totalMonthlyExpenses.value ?: 0.0

        val cal = Calendar.getInstance()
        val projections = mutableListOf<MonthProjection>()
        var accumulated = 0.0

        val monthNames = listOf("Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez")

        for (i in 0 until 24) {
            val month = (cal.get(Calendar.MONTH) + i) % 12
            val year = cal.get(Calendar.YEAR) + (cal.get(Calendar.MONTH) + i) / 12
            val profit = revenue - expenses
            accumulated += profit

            projections.add(
                MonthProjection(
                    monthLabel = "${monthNames[month]}/$year",
                    revenue = revenue,
                    expenses = expenses,
                    profit = profit,
                    accumulatedProfit = accumulated
                )
            )
        }
        projectionData.value = projections
    }

    fun getServerCreditsInfo(serverId: Long, totalCredits: Int, callback: (used: Int, available: Int) -> Unit) {
        viewModelScope.launch {
            val used = clientDao.getCreditsUsedByServer(serverId) ?: 0
            callback(used, totalCredits - used)
        }
    }
}
