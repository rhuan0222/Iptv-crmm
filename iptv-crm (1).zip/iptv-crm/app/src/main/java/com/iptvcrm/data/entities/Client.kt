package com.iptvcrm.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "clients")
data class Client(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val phone: String,
    val address: String,
    val plan: String,
    val planValue: Double,
    val dueDay: Int,              // dia do vencimento (1-31)
    val serverId: Long,           // FK para Server
    val creditsUsed: Int = 1,
    val origin: String,           // "Panfleto", "Internet", "Boca a Boca", "Outro"
    val startDate: Long = System.currentTimeMillis(),
    val active: Boolean = true,
    val notes: String = ""
)
