# IPTV CRM 📺

CRM completo para gestão de clientes de IPTV, com controle financeiro, projeções e gestão de servers/créditos.

## Funcionalidades

- **Clientes**: Cadastro com nome, telefone, endereço, plano, vencimento, server, origem e histórico de pagamentos
- **Financeiro**: Gastos por categoria (recorrentes e únicos), custo por cliente, CAC, lucro mensal
- **Projeção**: Gráfico de faturamento, gastos e lucro acumulado para os próximos 24 meses
- **Servers**: Cadastro de servers com custo por crédito, total de créditos, créditos usados/disponíveis
- **Origem**: Rastreio de onde vieram os clientes (Panfleto, Internet, Boca a Boca, Outro)

---

## Como compilar

### Opção 1 — Android Studio (recomendado)
1. Instale o [Android Studio](https://developer.android.com/studio)
2. Abra a pasta `iptv-crm` no Android Studio
3. Aguarde o Gradle sincronizar
4. Clique em **Build → Build Bundle(s)/APK(s) → Build APK(s)**
5. O APK estará em `app/build/outputs/apk/debug/app-debug.apk`

### Opção 2 — GitHub Actions (sem PC, APK na nuvem)
1. Crie uma conta no [github.com](https://github.com)
2. Crie um novo repositório
3. Suba todos os arquivos deste projeto
4. O GitHub vai compilar automaticamente a cada push
5. Vá em **Actions → Build APK → Artifacts** para baixar o APK

### Opção 3 — Terminal (Linux/Mac)
```bash
cd iptv-crm
chmod +x gradlew
./gradlew assembleDebug
```

---

## Estrutura do projeto

```
app/src/main/java/com/iptvcrm/
├── data/
│   ├── entities/     # Client, Server, Expense, Payment
│   ├── dao/          # Queries do banco de dados
│   └── database/     # AppDatabase (Room)
├── ui/
│   ├── dashboard/    # Tela inicial com gráficos
│   ├── clients/      # Lista, cadastro e pagamentos de clientes
│   ├── financial/    # Gastos e resumo financeiro
│   └── servers/      # Gestão de servers e créditos
└── MainActivity.kt
```

---

## Tecnologias
- **Kotlin** — linguagem principal
- **Room** — banco de dados local (SQLite)
- **LiveData + ViewModel** — arquitetura MVVM
- **Navigation Component** — navegação entre telas
- **MPAndroidChart** — gráficos de projeção e origem
- **Material Design 3** — UI moderna
